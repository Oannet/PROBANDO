#ifndef TEST_TO_STRING_CONNECT4_H
#define TEST_TO_STRING_CONNECT4_H

void execute_to_string_tests(char* test_name);

#endif