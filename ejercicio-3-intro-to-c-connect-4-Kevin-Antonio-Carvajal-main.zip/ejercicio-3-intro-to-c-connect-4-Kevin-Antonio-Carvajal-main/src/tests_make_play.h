#ifndef TEST_MAKE_PLAY_CONNECT4_H
#define TEST_MAKE_PLAY_CONNECT4_H

void execute_make_play_tests(char* test_name);

#endif