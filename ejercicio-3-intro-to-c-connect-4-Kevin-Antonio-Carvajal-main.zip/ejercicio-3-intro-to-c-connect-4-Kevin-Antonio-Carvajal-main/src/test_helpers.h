#ifndef TEST_CONNECT4_HELPER_H
#define TEST_CONNECT4_HELPER_H

#include "connect4.h"

void print_board(connect4* game);

#endif
