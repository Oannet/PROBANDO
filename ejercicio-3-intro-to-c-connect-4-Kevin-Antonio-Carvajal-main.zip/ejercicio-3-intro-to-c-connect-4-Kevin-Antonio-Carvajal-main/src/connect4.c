#include <stdlib.h>
#include <stdio.h>
#include "connect4.h"

void 
connect4_init (connect4* game, int rows, int columns, int num_of_players, int win_size) 
{  
}

void
connect4_free (connect4* game)
{
}

char* 
connect4_to_string (connect4* game)
{
  return "";
}

int 
connect4_make_play (connect4* game, int player, int column)
{
  return 0;
}

bool 
connect4_player_won (connect4* game, int player, int row, int column) 
{
  return false;
}
